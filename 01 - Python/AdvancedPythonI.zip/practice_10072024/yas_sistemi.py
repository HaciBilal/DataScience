age_list = []

def add_age():
    age = input("Yaşı giriniz: ")
    if age.isdigit():
        age_list.append(int(age))
        print(f"Yaş eklendi: {age}")
    else:
        print("Geçersiz bir yaş girdiniz. Lütfen tekrar deneyin.")
        
def list_ages():
    if not age_list:
        print("Henüz yaş eklenmedi.")
        
    else:
        print("Yaşlar: ")
        for age in age_list:
            print(f"- {age}")
            
def filter_ages(min_age, max_age):
    filtered_ages = list(filter(lambda age: min_age <= age <= max_age, age_list))
    
    if not filtered_ages:
        print(f"{min_age}-{max_age} yaş aralığında insan yok.")
        
    else:
        print(f"{min_age}-{max_age} yaş aralığındaki insanlar:")
        for age in filtered_ages:
            print(f"- {age}")
            
            
def main():
    while True:
        print("""
              Yaş Sınıflandırma Sistemi
              -------------------------
              1. Yaş Ekle
              2. Yaşları Listele
              3. Belirli Yaş Aralığındaki İnsanları Filtrele
              4. Çıkış
              """)
        
        choice = input("Seçiminiz (1-4): ")
        
        if choice == "1":
            add_age()
            
        elif choice == "2":
            list_ages()
            
        elif choice == "3":
            min_age = input("Minimum yaşı giriniz:")
            max_age = input("Maksimum yaşı giriniz:")
            
            if min_age.isdigit() and max_age.isdigit():
                filter_ages(int(min_age), int(max_age))
            else:
                print("Geçersiz yaş aralığı girdiniz. Lütfen tekrar deneyin.")
                
        elif choice == "4":
            print("Programdan çıkılıyor...")
            break
        
        else:
            print("Geçersiz seçim, lütfen tekrar deneyin")
            
main()