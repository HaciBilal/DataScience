def add_student(students):
    name = input("Öğrencinin adını giriniz: ")
    grades = []
    
    for i in range(1, 4):
        grade = input(f"{i}. dersin notunu giriniz: ")
        if grade.isdigit():
            grades.append(int(grade))
        else:
            print("Geçersiz not girdiniz. Lütfen tekrar deneyin.")
            return
        
    students[name] = grades
    
    print(f"{name} ismli öğrenci eklendi.")
    
def calculate_average(grades):
    return sum(grades) / len(grades)

def determine_status(average):
    if average >= 90:
        return "Mükemmel"
    elif average >= 75:
        return "İyi"
    elif average >= 50:
        return "Geçti"
    else:
        return "Kaldı"
    
    
def display_student_status(students):
    for name, grades in students.items():
        average = calculate_average(grades)
        status = determine_status(average)
        print(f"{name}: Ortalama - {average:.2f}, Durum - {status}")
        
        
def main():
    students = {}
    while True:
        print("""
              1. Öğrenci Ekle
              2. Öğrenci Durumlarını Görüntüle
              3. Çıkış
              """)
        
        choice = input("Lütfen bir seçim yapınız (1-3): ")
        
        if choice == "1":
            add_student(students)
            
        elif choice == "2":
            display_student_status(students)
            
        elif choice == "3":
            print("Programdan çıkılıyor...")
            break
        else:
            print("Geçersiz seçim, lütfen tekrar deneyiniz.")
            
main()

            