employees = []

def add_employee():
    name = input("Çalışanın adını giriniz: ")
    salary = input("Maaşını giriniz: ")
    
    if salary.isdigit():
        employees.append({"name": name, "salary": int(salary)})
        print(f"{name} adl çalışan eklendi.")
        
    else:
        print("Geçersiz maaş girdiniz. Lütfen tekrar deneyin.")
        

def list_employees():
    if not employees:
        print("Henüz çalışan eklenmedi.")
    else:
        for employee in employees:
            print(f"Çalışan: {employee['name']}, Maaş: {employee['salary']}")
            
def filter_employees_by_salary(min_salary):
    filtered_employees = list(filter(lambda employee: employee['salary'] > min_salary, employees))
    if not filtered_employees:
        print(f"{min_salary} maaşından yüksek maaşta çalışan yok")
        
    else:
        for employee in filtered_employees:
            print(f"Çalışan: {employee['name']}, Maaş: {employee['salary']}")
            
            
def main():
    while True:
        print("""
              Çalışan Maaş Yönetim Sistemi
              ----------------------------
              1. Çalışan Ekle
              2. Çalışanları Listele
              3. Belirli Maaştan Yüksek Olan Çalışanları Filtrele
              4. Çıkış
              """)
        
        choice = input("Lütfen size belirtilen listeden seçiminizi yapınız (1-4): ")
        
        if choice == "1":
            add_employee()
            
        elif choice == "2":
            list_employees()
            
        elif choice == "3":
            min_salary = input("Minimum maaş değerini giriniz: ")
            if min_salary.isdigit():
                filter_employees_by_salary(int(min_salary))
                
            else:
                print("Geçersiz maaş değeri girdiniz. Lütfen tekrar deneyiniz.")
                
        elif choice == "4":
            print("Programdan çıkılıyor...")
            break
        
        else:
            print("Geçersiz seçim. Lütfen tekrar deneyiniz.")
            
            
if __name__ == "__main__":
    main()