import random

def bilgisayar_secim():
    secim = ["taş", "kağıt", "makas"]
    return random.choice(secim)

def oyuncu_secim():
    while True:
        secim = input("Seçiminizi yapınız (taş, kağıt, makas): ").lower().strip()
        
        if secim in ["taş", "kağıt", "makas"]:
            return secim
        
        else:
            print("Geçersiz seçim. Lütfen 'taş', 'kağıt' veya 'makas' yazın.")
            
            
def karar(oyuncu_secim, bilgisayar_secim):
    if oyuncu_secim == bilgisayar_secim:
        return "Berabere!"
    
    elif (oyuncu_secim == "taş" and bilgisayar_secim == "makas") or \
        (oyuncu_secim == "kağıt" and bilgisayar_secim == "taş") or \
            (oyuncu_secim == "makas" and bilgisayar_secim == "kağıt"):
                
        return "Kazandınız!"
    
    else:
        return "Kaybettiniz!"
    
    
def main():
    print("Taş, Kağıt, Makas Oyununa Hoşgeldiniz!")
    
    while True:
        oyuncu_secimi_al = oyuncu_secim()
        bilgisayar_secimi_al = bilgisayar_secim()
        
        print(f"Siz: {oyuncu_secimi_al} - Bilgisayar: {bilgisayar_secimi_al}")
        
        sonuc = karar(oyuncu_secimi_al, bilgisayar_secimi_al)
        
        print(sonuc)
        
        tekrar = input("Tekrar oynamak ister misiniz? (evet/hayır): ").lower().strip()
        
        if tekrar != "evet":
            break
        
        
if __name__ == "__main__":
    main()