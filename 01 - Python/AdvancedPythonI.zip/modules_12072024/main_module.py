# main_module.py

import example_module

example_module.greet(input("Bir isim giriniz: "))

print("Bu modülün adı: ", __name__)

