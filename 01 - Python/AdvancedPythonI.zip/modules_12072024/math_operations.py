# math_operations.py

"""This module includes basic math operations."""

def sum_operations(a, b):
    """Adds two given numbers"""
    
    return a + b

def multiply(a, b):
    """Multiplies two given numbers"""
    
    return a * b

# print(sum_operations(6, 7))
# print(multiply(6, 7))

# print("__doc__ of math operations:", __doc__)
# print("__doc__ of sum operations function:", sum_operations.__doc__)
# print("__doc__ of multiply function:", multiply.__doc__)