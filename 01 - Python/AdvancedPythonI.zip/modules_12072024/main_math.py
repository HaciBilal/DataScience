import math_operations

print("Docstring of math operations module:", math_operations.__doc__)

sum_result = math_operations.sum_operations(5, 3)
mul_result = math_operations.multiply(5, 3)

print(f"Total: {sum_result}")
print(f"Multiply: {mul_result}")