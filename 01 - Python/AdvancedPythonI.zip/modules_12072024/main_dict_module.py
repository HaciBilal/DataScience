import example_dict_module

print("Dictionary of example_dict_module:", example_dict_module.__dict__)