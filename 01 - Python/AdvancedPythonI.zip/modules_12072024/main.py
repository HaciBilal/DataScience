# This is a simple module file

def sum_operation(a, b):
    """Adds two given numbers"""
    return a + b


print(sum_operation(30, 40))

print("Verilen iki sayının toplamı:", sum_operation(int(input("Bir sayı giriniz: ")), int(input("İkinci bir sayı giriniz: "))))