# import new as fn
# from new import factorial_calculate, fibonacci_series, square_root

from new import *


fact = factorial_calculate(5)
print("Factorial of 5:", fact)

fibo = fibonacci_series(6)
print("Fibonacci series:", fibo)

s_root = square_root(25)
print("Square root of 25:", s_root)