def hello():
    print("Hello, I am a special module!")