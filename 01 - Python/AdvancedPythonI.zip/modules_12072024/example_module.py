# example_module.py

print("Bu modülü doğrudan çalıştırırsanız adı:", __name__)

def greet(name):
    print(f"Hello, {name}!")
    
    
# greet(input("Bir isim giriniz: "))

