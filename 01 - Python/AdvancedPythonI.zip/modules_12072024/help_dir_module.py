# get help from the math module

# help("random")

import math

print("Math module elements: ", dir(math))