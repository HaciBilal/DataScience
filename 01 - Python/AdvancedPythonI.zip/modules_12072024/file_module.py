import random

import math_operations

import math

print("File path of the random module:", random.__file__)
print("File path of the math_operations module:", math_operations.__file__)

print("File path of the math module:", math.__file__)