# example_dict_module.py

def multiply(x, y):
    return x * y

def sum_opr(x, y):
    return x + y

def sub(x, y):
    return x - y

def div(x, y):
    return x / y