# Adım 1: Gereken Modüller
import os

# Adım 2: Fonksiyonlar

# 1. Kitap ve Yazar Ekleme
def add_book(book_list):
    book_title = input("Eklemek istediğiniz kitabın adını girin: ")
    author = input("Yazarın adını girin: ")
    book_list.append({'title': book_title, 'author': author})

def add_author(author_list):
    author_name = input("Eklemek istediğiniz yazarın adını girin: ")
    author_list.append(author_name)

# 2. Kitap ve Yazar Listesi Gösterme
def show_books(book_list):
    print("Kitap Listesi:")
    for book in book_list:
        print(f"- {book['title']} (Yazar: {book['author']})")

def show_authors(author_list):
    print("Yazar Listesi:")
    for author in author_list:
        print(f"- {author}")

# 3. Verileri Dosyaya Kaydetme ve Dosyadan Okuma
def save_to_file(filename, data):
    with open(filename, 'w') as file:
        for item in data:
            if isinstance(item, dict):
                file.write(f"{item['title']}|{item['author']}\n")
            else:
                file.write(f"{item}\n")

def read_from_file(filename, is_dict=False):
    if not os.path.exists(filename):
        return []
    with open(filename, 'r') as file:
        if is_dict:
            return [{'title': line.split('|')[0], 'author': line.split('|')[1].strip()} for line in file.readlines()]
        else:
            return [line.strip() for line in file.readlines()]

# Adım 3: Ana Program
def main():
    book_list = read_from_file("books.txt", is_dict=True)
    author_list = read_from_file("authors.txt")

    while True:
        print("\nBasit Veritabanı Yönetim Sistemi")
        print("1. Kitap Ekle")
        print("2. Kitapları Listele")
        print("3. Yazar Ekle")
        print("4. Yazarları Listele")
        print("5. Çık ve Verileri Kaydet")
        choice = input("Bir seçenek seçin (1-5): ")

        if choice == "1":
            add_book(book_list)
        elif choice == "2":
            show_books(book_list)
        elif choice == "3":
            add_author(author_list)
        elif choice == "4":
            show_authors(author_list)
        elif choice == "5":
            save_to_file("books.txt", book_list)
            save_to_file("authors.txt", author_list)
            print("Veriler kaydedildi. Çıkılıyor...")
            break
        else:
            print("Geçersiz seçenek. Lütfen tekrar deneyin.")

if __name__ == "__main__":
    main()
